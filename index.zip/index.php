<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<H1>Updated Hello World</H1>'; ?> 
 </body>
</html>